"""run_project.py -- one command to run the whole CityMart Retail Shop Co-Pilot pipeline (Parts A to D).

Usage (from the repository root, with the virtual environment active):
    python run_project.py                 # run every stage in order
    python run_project.py --only B C      # run only some parts
    python run_project.py --from B        # run from Part B onwards
    python run_project.py --skip-generate # keep the existing data/raw files

Each stage is a normal script, so it can also be run on its own (see README).
The runner stops at the first failing stage and checks that the files each
stage promises to write really exist before it moves on.
"""
import argparse
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.abspath(__file__))

# (part, label, command, files that must exist afterwards)
STAGES = [
    ("A", "Generate synthetic CityMart shop data", ["generate_data.py"],
     ["data/raw/customers.csv", "data/raw/sales.csv", "data/raw/tickets.csv", "data/policies/refund_policy.txt", "data/policies/pickup_policy.txt"]),
    ("A", "Clean the raw customers, products and sales", ["src/part_a_clean.py"],
     ["data/clean/customers.csv", "data/clean/sales.csv", "data/clean/products.csv"]),
    ("A", "Validate the clean tables", ["src/part_a_validate.py"], []),
    ("A", "Load SQLite and run the SQL queries", ["src/part_a_sql.py"], ["data/citymart.db"]),
    ("B", "RFM segments and lapse model", ["src/part_b.py"],
     ["outputs/customer_segments.csv", "outputs/lapse_model.joblib", "outputs/retention_list.csv"]),
    ("C", "Shop support ticket triage", ["-m", "src.part_c"],
     ["outputs/triage_results.csv", "outputs/triage_budget_demo.csv"]),
    ("D", "Shop-policy RAG retrieval and evaluation", ["-m", "src.part_d_rag"], []),
    ("D", "Refund agent (ReAct, human store-manager escalation, crash/resume)", ["-m", "src.part_d_agent"],
     ["outputs/agent_runs.jsonl", "outputs/refund_ledger.jsonl"]),
]


def run_stage(part, label, cmd, expected, index, total):
    print(f"\n{'=' * 72}\n[{index}/{total}] Part {part}: {label}\n{'=' * 72}", flush=True)
    start = time.time()
    result = subprocess.run([sys.executable] + cmd, cwd=ROOT)
    took = time.time() - start
    if result.returncode != 0:
        print(f"\nFAILED: Part {part} - {label} (exit code {result.returncode})")
        sys.exit(result.returncode)
    missing = [p for p in expected if not os.path.exists(os.path.join(ROOT, p))]
    if missing:
        print(f"\nFAILED: stage finished but these files were not written: {missing}")
        sys.exit(1)
    print(f"-> done in {took:.1f}s", flush=True)
    return took


def main():
    ap = argparse.ArgumentParser(description="Run the CityMart Co-Pilot pipeline.")
    ap.add_argument("--only", nargs="+", choices=list("ABCD"), help="run only these parts")
    ap.add_argument("--from", dest="start", choices=list("ABCD"), help="run from this part onwards")
    ap.add_argument("--skip-generate", action="store_true", help="do not regenerate data/raw")
    args = ap.parse_args()

    stages = list(STAGES)
    if args.only:
        stages = [s for s in stages if s[0] in args.only]
    elif args.start:
        stages = [s for s in stages if s[0] >= args.start]
    if args.skip_generate:
        stages = [s for s in stages if s[2] != ["generate_data.py"]]

    started = time.time()
    timings = [(f"Part {p}: {label}", run_stage(p, label, cmd, exp, i, len(stages)))
               for i, (p, label, cmd, exp) in enumerate(stages, 1)]

    print(f"\n{'=' * 72}\nSUMMARY\n{'=' * 72}")
    for name, secs in timings:
        print(f"  {name:<52} {secs:6.1f}s")
    print(f"  {'TOTAL':<52} {time.time() - started:6.1f}s\nALL STAGES COMPLETED")


if __name__ == "__main__":
    main()
