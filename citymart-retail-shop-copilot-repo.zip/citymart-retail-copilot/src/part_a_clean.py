"""Part A: audit raw data, clean, store to CSV + SQLite."""
import os, sqlite3
import pandas as pd, numpy as np

RAW, CLEAN = "data/raw", "data/clean"
os.makedirs(CLEAN, exist_ok=True)
cu = pd.read_csv(f"{RAW}/customers.csv"); pr = pd.read_csv(f"{RAW}/products.csv")
orr = pd.read_csv(f"{RAW}/sales.csv")

print("== AUDIT ==")
for name, df in [("customers", cu), ("products", pr), ("sales", orr)]:
    print(f"\n{name}: shape={df.shape}")
    print(pd.DataFrame({"dtype": df.dtypes.astype(str), "missing": df.isna().sum(),
                        "missing_pct": (df.isna().mean() * 100).round(2)}).to_string())
amt_num = pd.to_numeric(orr["sale_amount"], errors="coerce")
dm = pd.to_numeric(orr["counter_wait_minutes"], errors="coerce")
audit = {
 "raw sales rows": len(orr),
 "exact duplicate rows": int(orr.duplicated().sum()),
 "pending rows": int((orr.status == "pending").sum()),
 "distinct sale_id": int(orr.sale_id.nunique()),
 "non-numeric sale_amount": int((amt_num.isna()).sum()),
 "negative counter_wait_minutes": int((dm < 0).sum()),
 "blank counter_wait_minutes": int(orr.counter_wait_minutes.isna().sum()),
 "customers blank age": int(cu.age.isna().sum()),
 "customers age outside 10-100": int(((cu.age < 10) | (cu.age > 100)).sum()),
 "distinct raw city spellings": int(cu.city.nunique()),
 "distinct non-blank raw gender spellings": int(cu.gender.dropna().nunique()),
 "blank gender": int(cu.gender.isna().sum()),
}
print("\nAUDIT TABLE"); [print(f"{k}: {v}") for k, v in audit.items()]

# ---- customers
print("\n== CLEAN CUSTOMERS ==")
c = cu.copy()
before = c.city.copy()
c["city"] = c.city.str.strip().str.title()
print("city values changed:", int((before != c.city).sum()), "| cities:", c.city.nunique())
gmap = {"m": "male", "male": "male", "f": "female", "female": "female"}
gb = c.gender.copy()
c["gender"] = c.gender.fillna("").str.strip().str.lower().map(gmap).fillna("unknown")
print("gender values changed:", int((gb.fillna("") != c.gender).sum()))
bad = (c.age < 10) | (c.age > 100)
print("ages set to missing (outside 10-100):", int(bad.sum()))
c.loc[bad, "age"] = np.nan
n_missing = int(c.age.isna().sum())
c["age"] = c.age.fillna(c.groupby("city")["age"].transform("median"))
print("missing ages filled with city median:", n_missing)
c["signup_date"] = pd.to_datetime(c.signup_date)
print(c.city.value_counts().to_string()); print(c.gender.value_counts().to_string())
print("missing ages:", int(c.age.isna().sum()), "age range:", c.age.min(), c.age.max())

# ---- sales
print("\n== CLEAN SALES ==")
o = orr.copy(); n0 = len(o)
o["sale_ts"] = pd.to_datetime(o.sale_ts)
o = o.drop_duplicates(); print("exact duplicates removed:", n0 - len(o)); n1 = len(o)
o = o.sort_values(["sale_id", "sale_ts"]).drop_duplicates("sale_id", keep="last")
print("older records dropped (kept latest per sale_id):", n1 - len(o))
o["sale_amount"] = pd.to_numeric(o.sale_amount, errors="coerce")
o = o.merge(pr[["product_id", "category", "price_inr"]], on="product_id", how="left")
miss = o.sale_amount.isna()
o.loc[miss, "sale_amount"] = (o.price_inr * o.quantity * (1 - o.discount_pct / 100)).round(2)[miss]
print("sale_amount filled from product price:", int(miss.sum()))
o["counter_wait_minutes"] = pd.to_numeric(o.counter_wait_minutes, errors="coerce")
neg = o.counter_wait_minutes < 0
o.loc[neg, "counter_wait_minutes"] = np.nan; print("negative counter_wait_minutes set to missing:", int(neg.sum()))
comp = o.status == "completed"
med = o.assign(dm_c=o.counter_wait_minutes.where(comp)).groupby("category")["dm_c"].transform("median")
fill = comp & o.counter_wait_minutes.isna()
o.loc[fill, "counter_wait_minutes"] = med[fill]
print("completed counter_wait_minutes filled with category median:", int(fill.sum()))
o = o.drop(columns=["category", "price_inr"]).sort_values("sale_id").reset_index(drop=True)
print("rows:", len(o), "| status:", o.status.value_counts().to_dict())
print("missing amount:", int(o.sale_amount.isna().sum()),
      "| missing counter wait completed:", int(o[o.status=='completed'].counter_wait_minutes.isna().sum()),
      "| missing counter wait cancelled:", int(o[o.status=='cancelled'].counter_wait_minutes.isna().sum()))
print("completed revenue INR %.2f" % o[o.status == "completed"].sale_amount.sum())

# ---- store
o_out = o.copy(); o_out["sale_ts"] = o_out.sale_ts.dt.strftime("%Y-%m-%d %H:%M:%S")
c_out = c.copy(); c_out["signup_date"] = c_out.signup_date.dt.strftime("%Y-%m-%d")
c_out.to_csv(f"{CLEAN}/customers.csv", index=False); pr.to_csv(f"{CLEAN}/products.csv", index=False)
o_out.to_csv(f"{CLEAN}/sales.csv", index=False)
if os.path.exists("data/citymart.db"): os.remove("data/citymart.db")
con = sqlite3.connect("data/citymart.db")
c_out.to_sql("customers", con, index=False); pr.to_sql("products", con, index=False)
o_out.to_sql("sales", con, index=False); con.close()
print("\nstored CSVs and data/citymart.db")
