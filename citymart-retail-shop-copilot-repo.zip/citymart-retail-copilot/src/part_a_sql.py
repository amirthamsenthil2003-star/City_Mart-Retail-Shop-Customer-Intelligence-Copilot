"""Run the 7 SQL queries and pandas cross-checks."""
import re, sqlite3, pandas as pd, numpy as np
con = sqlite3.connect("data/citymart.db")
qs = [q.strip() for q in re.split(r"-- Q\d:[^\n]*\n", open("sql/queries.sql").read()) if q.strip()]
R = [pd.read_sql_query(q, con) for q in qs]
print("Q1 customers:", len(R[0]))
print("Q2 rows:", len(R[1]), "sum: %.2f" % R[1].revenue.sum()); print(R[1].head(1).to_string(index=False))
print("Q3 products:", len(R[2])); print("Q4 customers:", len(R[3]))
print("Q5 customers:", len(R[4]), "avg:", R[4].avg_total.iloc[0])
q6 = R[5]; print(q6[q6.row_num == 1][["city", "customer_id", "total_spend"]].to_string(index=False))
print("Q6 rows rank != row_number:", int((q6.rnk != q6.row_num).sum()))
print("Q7 rows:", len(R[6]), "last cumulative:", R[6].cumulative_revenue.iloc[-1])

o = pd.read_sql_query("select * from sales where status='completed'", con)
cu = pd.read_sql_query("select * from customers", con); pr = pd.read_sql_query("select * from products", con)
m = o.merge(cu, on="customer_id").merge(pr, on="product_id")
pv = pd.pivot_table(m, values="sale_amount", index="city", columns="category", aggfunc="sum", margins=True)
print("\npivot grand total: %.2f" % pv.loc["All", "All"], "| SQL total: %.2f" % R[1].revenue.sum())
g = m.groupby("city").agg(sum=("sale_amount", "sum"), mean=("sale_amount", "mean"), count=("sale_amount", "count")).round(2)
print(g.to_string())
x = o.sale_amount
q1, q3 = x.quantile(.25), x.quantile(.75); iqr = q3 - q1; lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
print("\nmean %.2f median %.2f skew %.2f Q1 %.2f Q3 %.2f" % (x.mean(), x.median(), x.skew(), q1, q3))
print("fences lower %.2f upper %.2f | outliers below %d above %d" % (lo, hi, (x < lo).sum(), (x > hi).sum()))
cm = o[["sale_amount", "discount_pct", "quantity", "counter_wait_minutes"]].corr().round(3); print(cm.to_string())
