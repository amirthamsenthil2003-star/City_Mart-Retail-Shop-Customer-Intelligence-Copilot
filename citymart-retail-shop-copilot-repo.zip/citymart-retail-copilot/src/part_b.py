"""Part B: RFM, K-means, PCA, lapse prediction for CityMart shop customers."""
import os
import numpy as np, pandas as pd, joblib
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, confusion_matrix, precision_score, recall_score, f1_score, accuracy_score
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.base import clone

os.makedirs("outputs", exist_ok=True)
o = pd.read_csv("data/clean/sales.csv", parse_dates=["sale_ts"])
cu = pd.read_csv("data/clean/customers.csv", parse_dates=["signup_date"])
pr = pd.read_csv("data/clean/products.csv")
comp = o[o.status == "completed"]

# ---------- Task 1: RFM ----------
snap = pd.Timestamp("2025-10-01 00:00:00")
g = comp.groupby("customer_id")
rfm = pd.DataFrame({"last": g.sale_ts.max(), "frequency": g.sale_id.nunique(), "monetary": g.sale_amount.sum()})
rfm["recency"] = (snap - rfm["last"]).dt.days
rfm = rfm[["recency", "frequency", "monetary"]].reset_index()
print("== RFM ==", len(rfm), "customers")
print("recency median %d min %d max %d" % (rfm.recency.median(), rfm.recency.min(), rfm.recency.max()))
print("frequency mean %.2f max %d | monetary mean %.2f max %.2f" % (rfm.frequency.mean(), rfm.frequency.max(), rfm.monetary.mean(), rfm.monetary.max()))

# ---------- Task 2: K-means ----------
Xs = StandardScaler().fit_transform(rfm[["recency", "frequency", "monetary"]])
print("\n== K-means ==\nK inertia silhouette")
for k in range(2, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(Xs)
    print(k, round(km.inertia_, 1), round(silhouette_score(Xs, km.labels_), 3))
K = 4
km = KMeans(n_clusters=K, n_init=10, random_state=42).fit(Xs)
rfm["segment_id"] = km.labels_

# ---------- Task 3: profile ----------
prof = rfm.groupby("segment_id").agg(size=("customer_id", "count"), recency=("recency", "mean"),
                                     frequency=("frequency", "mean"), monetary=("monetary", "mean")).round(2)
print("\n== Segment profile ==\n", prof.to_string())
premium_id = prof.monetary.idxmax()
# names derived from the profile: rule-based so they do not depend on arbitrary cluster numbers
names = {}
for sid, r in prof.iterrows():
    if sid == premium_id: names[sid] = "Premium Big Spenders"
    elif r.recency >= prof.recency.max() - 1e-9: names[sid] = "Lapsing / At-Risk"
    elif r.frequency >= prof.drop(premium_id).frequency.max() - 1e-9: names[sid] = "Loyal Frequent Buyers"
    else: names[sid] = "Occasional Low-Value"
rfm["segment_name"] = rfm.segment_id.map(names)
rfm["is_premium"] = rfm.segment_id == premium_id
print("premium segment id:", premium_id, "| names:", names)
pca = PCA(n_components=2).fit(Xs); ev = pca.explained_variance_ratio_
print("PCA explained variance ratio:", ev.round(3), "total %.3f" % ev.sum())
rfm[["customer_id", "recency", "frequency", "monetary", "segment_id", "segment_name", "is_premium"]].to_csv("outputs/customer_segments.csv", index=False)

# ---------- Task 4: lapse problem ----------
cut = pd.Timestamp("2025-09-01")
pre = o[o.sale_ts < cut]; pre_c = pre[pre.status == "completed"]
cohort_ids = pre_c.customer_id.unique()
sep = comp[(comp.sale_ts >= cut) & (comp.sale_ts < pd.Timestamp("2025-10-01"))].customer_id.unique()
gc = pre_c.groupby("customer_id")
F = pd.DataFrame({"last": gc.sale_ts.max(), "frequency": gc.sale_id.nunique(), "monetary": gc.sale_amount.sum(),
                  "avg_discount": gc.discount_pct.mean(), "avg_wait": gc.counter_wait_minutes.mean()})
F["recency"] = (cut - F["last"]).dt.days
fin = pre[pre.status.isin(["completed", "cancelled"])]
F["cancel_rate"] = (fin.assign(c=fin.status == "cancelled").groupby("customer_id").c.mean()).reindex(F.index)
fav = pre_c.merge(pr[["product_id", "category"]], on="product_id").groupby("customer_id").category.agg(lambda s: s.value_counts().sort_index().idxmax())
F["fav_category"] = fav
F = F.drop(columns="last").reset_index().merge(cu[["customer_id", "city", "age", "gender", "signup_date"]], on="customer_id")
F["tenure_days"] = (cut - F.signup_date).dt.days
F = F.drop(columns="signup_date")
F["lapsed"] = (~F.customer_id.isin(sep)).astype(int)
num = ["recency", "frequency", "monetary", "avg_discount", "cancel_rate", "avg_wait", "age", "tenure_days"]
cat = ["city", "gender", "fav_category"]
X, y = F[num + cat], F.lapsed
print("\n== Lapse cohort ==", len(F), "lapsed", int(y.sum()), "(%.2f%%)" % (100 * y.mean()))
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
print("train", len(Xtr), "test", len(Xte))
print("any missing in features:", bool(X.isna().any().any()))
assert not X.isna().any().any()
base = np.zeros(len(yte), dtype=int)
print("baseline acc %.3f F1 %.3f" % (accuracy_score(yte, base), f1_score(yte, base, zero_division=0)))

# ---------- Task 5/6: pipelines + tuning ----------
def prep(): return ColumnTransformer([("num", StandardScaler(), num), ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), cat)])
lr_pipe = Pipeline([("prep", prep()), ("clf", LogisticRegression(max_iter=1000))])
rf_pipe = Pipeline([("prep", prep()), ("clf", RandomForestClassifier(n_estimators=100, random_state=42))])
gl = GridSearchCV(lr_pipe, {"clf__C": [0.01, 0.1, 1, 10, 100]}, cv=5, scoring="f1").fit(Xtr, ytr)
gr = GridSearchCV(rf_pipe, {"clf__max_depth": [3, 5, 8], "clf__min_samples_leaf": [5, 10, 20]}, cv=5, scoring="f1").fit(Xtr, ytr)
print("\nscaler mean frequency (train only): %.3f | full cohort mean frequency: %.3f" % (
    gl.best_estimator_.named_steps["prep"].named_transformers_["num"].mean_[num.index("frequency")], F.frequency.mean()))
print("LR best", gl.best_params_, "cv F1 %.4f" % gl.best_score_)
print("RF best", gr.best_params_, "cv F1 %.4f" % gr.best_score_)
def rep(name, m, Xt=Xte):
    p = m.predict(Xt); print(f"{name}: cm {confusion_matrix(yte, p).tolist()} precision {precision_score(yte, p, zero_division=0):.3f} recall {recall_score(yte, p, zero_division=0):.3f} F1 {f1_score(yte, p, zero_division=0):.3f}")
    return p
rep("LogReg", gl.best_estimator_); rep("RandomForest", gr.best_estimator_)

# ---------- Task 7: oversampling ----------
rs = np.random.RandomState(42)
pos = np.where(ytr.values == 1)[0]; neg = np.where(ytr.values == 0)[0]
extra = rs.choice(pos, size=len(neg) - len(pos), replace=True)
idx = np.concatenate([np.arange(len(ytr)), extra])
Xb, yb = Xtr.iloc[idx], ytr.iloc[idx]
print("\nbalanced train counts:", yb.value_counts().to_dict())
lr_bal = clone(gl.best_estimator_).fit(Xb, yb)
rep("LogReg (unbalanced)", gl.best_estimator_); rep("LogReg (oversampled)", lr_bal)

# ---------- Task 8: interpret, persist, use ----------
best_name, best = ("RandomForest", gr.best_estimator_) if f1_score(yte, gr.best_estimator_.predict(Xte)) >= f1_score(yte, gl.best_estimator_.predict(Xte)) else ("LogReg", gl.best_estimator_)
print("\nselected model:", best_name)
fn = gr.best_estimator_.named_steps["prep"].get_feature_names_out()
imp = pd.Series(gr.best_estimator_.named_steps["clf"].feature_importances_, index=fn).sort_values(ascending=False)
print("RF top-5 features:\n", imp.head(5).round(4).to_string())
coef = pd.Series(gl.best_estimator_.named_steps["clf"].coef_[0], index=gl.best_estimator_.named_steps["prep"].get_feature_names_out())
print("LR coefficients:\n", coef[["num__recency", "num__frequency", "num__monetary", "num__cancel_rate"]].round(3).to_string())
joblib.dump(best, "outputs/lapse_model.joblib")
re_ld = joblib.load("outputs/lapse_model.joblib")
print("reloaded predictions identical:", bool((re_ld.predict(Xte) == best.predict(Xte)).all()))
proba = best.predict_proba(Xte)[:, 1]
te = pd.DataFrame({"customer_id": F.loc[Xte.index, "customer_id"].values, "lapse_probability": proba, "actually_lapsed": yte.values})
te = te.merge(rfm[["customer_id", "is_premium"]], on="customer_id", how="left")
ret = te[te.is_premium == True].sort_values("lapse_probability", ascending=False).head(10)
ret[["customer_id", "lapse_probability", "actually_lapsed"]].round(4).to_csv("outputs/retention_list.csv", index=False)
print("premium test customers:", int((te.is_premium == True).sum()), "| retention list rows:", len(ret), "| truly lapsed:", int(ret.actually_lapsed.sum()))
