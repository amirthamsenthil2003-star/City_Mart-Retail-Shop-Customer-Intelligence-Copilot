"""Part D tasks 5-9: CityMart refund agent - tools, ReAct loop, safety limits, checkpoint/resume."""
import glob, json, os, sqlite3, time
from datetime import datetime
import pandas as pd
import mock_llm
from src.part_d_rag import retrieve

DB, LEDGER, STATE, RUNS = "data/citymart.db", "outputs/refund_ledger.jsonl", "state", "outputs/agent_runs.jsonl"
os.makedirs(STATE, exist_ok=True); os.makedirs(os.path.dirname(LEDGER), exist_ok=True)

class SimulatedCrash(Exception): pass

# ---------------- tools ----------------
def get_sale(sale_id):
    con = sqlite3.connect(DB)
    r = con.execute("SELECT sale_id, status, sale_amount, counter_wait_minutes FROM sales WHERE sale_id = ?", (sale_id,)).fetchone()
    con.close()
    if r is None: return {"error": "sale not found"}
    dm = None if r[3] is None or r[3] != r[3] else float(r[3])
    return {"sale_id": r[0], "status": r[1], "sale_amount": float(r[2]), "counter_wait_minutes": dm}

def search_policy(query):
    return {"results": retrieve(query, 3)}

def calculate_refund(sale_amount, counter_wait_minutes):
    if counter_wait_minutes is not None and float(counter_wait_minutes) > 45:
        return {"refund_inr": round(float(sale_amount), 2)}
    return {"refund_inr": 0}

def _ledger(tool, sale_id, refund_inr):
    with open(LEDGER, "a") as f:
        f.write(json.dumps({"timestamp": datetime.now().isoformat(timespec="seconds"), "tool": tool,
                            "sale_id": sale_id, "refund_inr": refund_inr}) + "\n")
    return {"refund_inr": refund_inr}

def issue_refund(sale_id, refund_inr): return _ledger("issue_refund", sale_id, refund_inr)
def escalate_to_human(sale_id, refund_inr): return _ledger("escalate_to_human", sale_id, refund_inr)

def _spec(name, desc, props): return {"name": name, "description": desc,
    "parameters": {"type": "object", "properties": props, "required": list(props)}}
TOOLS_SPEC = [
    _spec("get_sale", "Look up a sale's status, amount and counter wait time in the shop database.", {"sale_id": {"type": "string"}}),
    _spec("search_policy", "Search the policy documents and return the most relevant chunks.", {"query": {"type": "string"}}),
    _spec("calculate_refund", "Compute the refund in INR from the sale amount and counter wait minutes.",
          {"sale_amount": {"type": "number"}, "counter_wait_minutes": {"type": "number"}}),
    _spec("issue_refund", "Issue an automatic refund of up to INR 1000 and record it in the ledger.",
          {"sale_id": {"type": "string"}, "refund_inr": {"type": "number"}}),
    _spec("escalate_to_human", "Escalate a refund above INR 1000 to a human store manager.",
          {"sale_id": {"type": "string"}, "refund_inr": {"type": "number"}})]
TOOL_MAP = {"get_sale": get_sale, "search_policy": search_policy, "calculate_refund": calculate_refund,
            "issue_refund": issue_refund, "escalate_to_human": escalate_to_human}
SYSTEM = ("You are a refund AGENT for CityMart retail shop support. Use the tools to look up the sale, check the policy, "
          "compute the refund, then issue it or escalate it. Finish with STATUS: explanation.")

# ---------------- loop ----------------
def _save(s):
    with open(os.path.join(STATE, f"{s['run_id']}.json"), "w") as f: json.dump(s, f, default=str)

def _fallback(s, status, why):
    done = [x["tool"] for x in s["steps"]]
    s.update(status=status, final_answer=f"HANDOFF to human agent: {why}. Scenario {s['scenario_id']}; tools done so far: {done or 'none'}; "
             f"model calls {s['llm_calls']}, tokens {s['tokens_used']}.")
    return s

def _loop(s, max_iterations, token_limit, time_limit_seconds, crash_after_tools=None):
    start = time.monotonic()
    while True:
        if time.monotonic() - start >= time_limit_seconds: return _fallback(s, "FALLBACK_TIMEOUT", "time limit reached")
        if s["llm_calls"] >= max_iterations: return _fallback(s, "FALLBACK_MAX_ITERATIONS", f"no final answer after {max_iterations} model calls")
        resp = mock_llm.chat(s["messages"], TOOLS_SPEC)
        s["llm_calls"] += 1; s["tokens_used"] += resp.usage.total_tokens
        if s["tokens_used"] > token_limit: return _fallback(s, "FALLBACK_TOKEN_LIMIT", f"token limit {token_limit} exceeded")
        msg = resp.choices[0].message
        if not msg.tool_calls:
            s["final_answer"] = msg.content; s["status"] = msg.content.split(":")[0].strip(); return s
        tc = msg.tool_calls[0]
        s["messages"].append({"role": "assistant", "content": None, "tool_calls": [{"id": tc.id, "name": tc.name, "arguments": tc.arguments}]})
        obs = TOOL_MAP[tc.name](**tc.arguments)
        s["messages"].append({"role": "tool", "tool_call_id": tc.id, "name": tc.name, "content": json.dumps(obs)})
        s["steps"].append({"tool": tc.name, "arguments": tc.arguments, "observation": obs})
        s["tools_executed"].append(tc.name); s["step"] = len(s["steps"])
        _save(s)                                              # checkpoint after every observation
        if crash_after_tools and len(s["tools_executed"]) == crash_after_tools:
            raise SimulatedCrash(f"simulated crash after tool #{crash_after_tools}")

def _refund_of(s):
    if s["status"] in ("REFUND", "ESCALATE"):
        for st in reversed(s["steps"]):
            if st["tool"] in ("issue_refund", "escalate_to_human"): return st["observation"]["refund_inr"]
    return 0

def run_agent(user_message, scenario_id, max_iterations=6, token_limit=6000, time_limit_seconds=10, run_id=None, crash_after_tools=None):
    s = {"run_id": run_id or f"{scenario_id}-{int(time.time()*1000)}", "scenario_id": scenario_id,
         "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": user_message}],
         "tokens_used": 0, "llm_calls": 0, "step": 0, "steps": [], "tools_executed": [], "status": None, "final_answer": None,
         "limits": {"max_iterations": max_iterations, "token_limit": token_limit, "time_limit_seconds": time_limit_seconds}}
    s = _loop(s, max_iterations, token_limit, time_limit_seconds, crash_after_tools)
    s["refund_inr"] = _refund_of(s); _save(s); return s

def resume_agent(run_id):
    s = json.load(open(os.path.join(STATE, f"{run_id}.json"))); L = s["limits"]
    s = _loop(s, L["max_iterations"], L["token_limit"], L["time_limit_seconds"])
    s["refund_inr"] = _refund_of(s); _save(s); return s

if __name__ == "__main__":
    for p in glob.glob(os.path.join(STATE, "*.json")): os.remove(p)
    for p in (LEDGER, RUNS): open(p, "w").close()
    sc = pd.read_csv("data/raw/agent_scenarios.csv")
    print("scenario | status | refund | expected | model calls | tokens")
    for r in sc.itertuples():
        mock_llm.reset()
        s = run_agent(r.message, r.scenario_id, run_id=f"{r.scenario_id}-main")
        ok = abs(s["refund_inr"] - r.expected_refund_inr) < 0.01 and (s["status"] == r.expected_outcome or r.expected_outcome == "FALLBACK" and s["status"].startswith("FALLBACK"))
        print(f"{r.scenario_id} | {s['status']} | {s['refund_inr']:.2f} | {r.expected_outcome} {r.expected_refund_inr:.2f} | {s['llm_calls']} | {s['tokens_used']} | match={ok}")
        with open(RUNS, "a") as f:
            f.write(json.dumps({"scenario_id": s["scenario_id"], "status": s["status"], "final_answer": s["final_answer"],
                                "llm_calls": s["llm_calls"], "tokens_used": s["tokens_used"], "steps": s["steps"]}) + "\n")
    s1 = sc.iloc[0]
    d = run_agent(s1.message, "S1", token_limit=200, run_id="S1-demo-tokenlimit"); print("\ntoken_limit=200 demo:", d["status"], "| tokens", d["tokens_used"], "| steps", len(d["steps"]), "|", d["final_answer"])
    d = run_agent(s1.message, "S1", time_limit_seconds=0, run_id="S1-demo-timeout"); print("time_limit_seconds=0 demo:", d["status"], "| llm_calls", d["llm_calls"], "|", d["final_answer"])
    mock_llm.reset()
    try: run_agent(s1.message, "S1", run_id="S1-crash", crash_after_tools=2); print("no crash?!")
    except SimulatedCrash as e:
        print("\nCRASH:", e); print("checkpoint tools so far:", json.load(open("state/S1-crash.json"))["tools_executed"])
    r = resume_agent("S1-crash")
    print("resume final:", r["status"], r["refund_inr"], "| tools executed across crash+resume:", r["tools_executed"], "| total llm_calls", r["llm_calls"])
    print("ledger lines:", sum(1 for _ in open(LEDGER)), "| state files:", len(glob.glob("state/*.json")))
