"""Validation of Part A checkpoints for the CityMart sales data."""
import sqlite3, pandas as pd
con = sqlite3.connect("data/citymart.db")
o = pd.read_sql_query("select * from sales", con); c = pd.read_sql_query("select * from customers", con)
comp = o[o.status == "completed"]
checks = [
 ("sales rows 12309", len(o) == 12309), ("distinct sale_id 12309", o.sale_id.nunique() == 12309),
 ("completed 11110", (o.status == "completed").sum() == 11110), ("cancelled 1199", (o.status == "cancelled").sum() == 1199),
 ("no pending", (o.status == "pending").sum() == 0), ("0 missing amount", o.sale_amount.isna().sum() == 0),
 ("0 missing counter wait completed", comp.counter_wait_minutes.isna().sum() == 0),
 ("1199 missing counter wait cancelled", o[o.status == "cancelled"].counter_wait_minutes.isna().sum() == 1199),
 ("revenue 5482397.60", round(comp.sale_amount.sum(), 2) == 5482397.60),
 ("six cities", c.city.nunique() == 6),
 ("city counts", c.city.value_counts().to_dict() == {"Pune": 227, "Delhi": 210, "Bengaluru": 197, "Chennai": 191, "Hyderabad": 191, "Mumbai": 184}),
 ("genders", c.gender.value_counts().to_dict() == {"female": 610, "male": 560, "unknown": 30}),
 ("0 missing ages, 18-60", c.age.isna().sum() == 0 and c.age.between(18, 60).all()),
]
ok = True
for name, r in checks:
    print(("PASS " if r else "FAIL ") + name); ok &= bool(r)
if ok: print("ALL CHECKPOINTS PASSED")
