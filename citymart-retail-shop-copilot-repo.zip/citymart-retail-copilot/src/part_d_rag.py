"""Part D tasks 1-4: CityMart shop-policy chunking, TF-IDF retrieval, grounded answers, evaluation."""
import glob, os
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import mock_llm

POLICY_DIR = os.path.join("data", "policies")

def chunk_text(text, size=40, overlap=10):
    words, step, out, start = text.split(), size - overlap, [], 0
    while True:
        out.append(" ".join(words[start:start + size]))
        if start + size >= len(words): break
        start += step
    return out

def build_chunks(size=40, overlap=10):
    chunks = []
    for path in sorted(glob.glob(os.path.join(POLICY_DIR, "*.txt"))):
        for c in chunk_text(open(path, encoding="utf-8").read(), size, overlap):
            chunks.append({"source": os.path.basename(path), "text": c})
    return chunks

class Retriever:
    def __init__(self, size=40, overlap=10):
        self.chunks = build_chunks(size, overlap)
        self.vec = TfidfVectorizer()
        self.matrix = self.vec.fit_transform([c["text"] for c in self.chunks])
    def retrieve(self, query, k=3):
        sims = cosine_similarity(self.vec.transform([query]), self.matrix)[0]
        top = sims.argsort()[::-1][:k]
        return [{"source": self.chunks[i]["source"], "score": round(float(sims[i]), 4), "text": self.chunks[i]["text"]} for i in top]

_DEFAULT = Retriever()
def retrieve(query, k=3): return _DEFAULT.retrieve(query, k)

SYSTEM = ("You are a POLICY ASSISTANT. Answer only from the supplied context. "
          "If the context does not contain the answer, say you could not find the information in the policy documents.")

def answer(question, retriever=None):
    r = retriever or _DEFAULT
    hits = r.retrieve(question, 3)
    ctx = "\n".join(f"[{h['source']}]\n{h['text']}" for h in hits)
    user = f"CONTEXT:\n{ctx}\nQUESTION:\n{question}"
    resp = mock_llm.chat([{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}])
    return resp.choices[0].message.content, [h["source"] for h in hits]

def evaluate(retriever):
    ev = pd.read_csv("data/raw/policy_eval.csv", keep_default_na=False)
    doc_ok = fact_ok = fb_ok = 0; fails = []
    for q in ev.itertuples():
        text, srcs = answer(q.question, retriever)
        if q.expected_doc == "NONE":
            ok = text.startswith("I could not find"); fb_ok += ok
            if not ok: fails.append((q.question, "no fallback", text))
        else:
            d = q.expected_doc in srcs; f = q.expected_fact in text
            doc_ok += d; fact_ok += f
            if not (d and f): fails.append((q.question, f"doc_in_top3={d} fact_in_answer={f}", text))
    return doc_ok, fact_ok, fb_ok, fails

if __name__ == "__main__":
    ch = _DEFAULT.chunks
    print("total chunks:", len(ch), pd.Series([c["source"] for c in ch]).value_counts().to_dict())
    print("retrieve('refund policy counter wait') sources:", [h["source"] for h in retrieve("refund policy counter wait")])
    for name, r in [("overlap 10", _DEFAULT), ("overlap 0", Retriever(40, 0))]:
        d, f, u, fails = evaluate(r)
        print(f"\n[{name}] chunks={len(r.chunks)} | answerable: expected_doc in top3 {d}/12, fact in answer {f}/12 | unanswerable fallback {u}/2")
        for q, why, t in fails: print("  FAIL:", q, "|", why, "|", t)
