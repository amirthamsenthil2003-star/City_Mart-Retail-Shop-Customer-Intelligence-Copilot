"""Part C: CityMart shop support-ticket triage with guardrails."""
import json, os, random, re, time
import pandas as pd
import mock_llm
from mock_llm import est_tokens, TransientLLMError

MAX_INPUT_TOKENS, BASE_DELAY, MAX_RETRIES = 400, 0.05, 3
CATS = ["billing", "store_service", "technical", "fraud"]
PATTERNS = [("EMAIL", re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "[EMAIL]"),
            ("PHONE", re.compile(r"\b[6-9]\d{9}\b"), "[PHONE]"),
            ("SALE_ID", re.compile(r"SALE-\d{6}"), "[SALE_ID]")]

ZERO_SHOT = ('You CLASSIFY support tickets. Allowed categories: billing, store_service, technical, fraud. '
             'Reply with JSON only, no other text: {"category": "...", "reason": "..."}')
FEW_SHOT = ZERO_SHOT + """
EXAMPLES:
Ticket: Someone used my card without permission, there is an unauthorized transaction. -> {"category": "fraud", "reason": "unauthorized payment"}
Ticket: I was charged twice and the invoice amount is wrong. -> {"category": "billing", "reason": "payment or invoice issue"}
Ticket: The app crashes and I cannot login. -> {"category": "technical", "reason": "app problem"}
Ticket: I am waiting at the pickup counter and the staff is not answering. -> {"category": "store_service", "reason": "counter wait"}"""

def redact(text, counts=None):
    for name, pat, ph in PATTERNS:
        text, n = pat.subn(ph, text)
        if counts is not None: counts[name] += n
    return text

def call_with_retry(messages, ticket_id, log):
    for retry in range(MAX_RETRIES + 1):
        try:
            return mock_llm.chat(messages), retry
        except TransientLLMError as e:
            if retry == MAX_RETRIES: raise
            wait = BASE_DELAY * 2 ** retry * random.uniform(0.9, 1.15)
            log.append((ticket_id, retry, wait)); print(f"[retry] ticket={ticket_id} retry={retry} wait={wait:.4f}s ({e})")
            time.sleep(wait)

def parse(text):
    try:
        d = json.loads(text)
        if isinstance(d, dict) and d.get("category") in CATS: return "classified_json", d["category"]
        return "flagged_invalid_output", None
    except (json.JSONDecodeError, TypeError):
        found = [c for c in CATS if c in re.findall(r"[a-z]+", (text or "").lower())]
        return ("classified_keyword", found[0]) if len(found) == 1 else ("flagged_invalid_output", None)

def run_pipeline(tickets, system_prompt, budget=None, quiet=True):
    mock_llm.reset(); log, sent, rows, total = [], [], [], 0
    for t in tickets.itertuples():
        row = dict(ticket_id=t.ticket_id, customer_id=t.customer_id, status=None, category=None, tokens_used=0, true=t.true_category)
        text = t.text
        if not text.strip(): row["status"] = "skipped_empty"
        elif est_tokens(text) > MAX_INPUT_TOKENS: row["status"] = "flagged_long"
        elif budget is not None and total >= budget: row["status"] = "budget_exhausted"
        else:
            msgs = [{"role": "system", "content": system_prompt}, {"role": "user", "content": redact(text)}]
            sent.append(msgs)
            resp, _ = call_with_retry(msgs, t.ticket_id, log)
            tok = resp.usage.total_tokens; total += tok; row["tokens_used"] = tok
            row["status"], row["category"] = parse(resp.choices[0].message.content)
        rows.append(row)
    return pd.DataFrame(rows), sent, log, total

def summarize(name, df, total):
    cl = df[df.status.isin(["classified_json", "classified_keyword"])]
    acc = (cl.category == cl.true).mean()
    print(f"\n[{name}] statuses: {df.status.value_counts().to_dict()}")
    print(f"[{name}] classified {len(cl)} | accuracy {acc*100:.1f}% ({int((cl.category==cl.true).sum())}/{len(cl)}) | total tokens {total} | tokens/classified ticket {total/len(cl):.2f}")
    return cl

if __name__ == "__main__":
    os.makedirs("outputs", exist_ok=True)
    tk = pd.read_csv("data/raw/tickets.csv", keep_default_na=False, dtype=str)
    seg = pd.read_csv("outputs/customer_segments.csv")
    # guardrail + redaction audit
    print("empty:", int((tk.text.str.strip() == "").sum()), "| long:", int((tk.text.map(est_tokens) > MAX_INPUT_TOKENS).sum()),
          "| long est tokens:", sorted(set(tk.text.map(est_tokens)[tk.text.map(est_tokens) > MAX_INPUT_TOKENS])))
    counts = {"EMAIL": 0, "PHONE": 0, "SALE_ID": 0}
    red = [redact(x, counts) for x in tk.text]
    print("substitutions:", counts, "total", sum(counts.values()))
    print("left after redaction:", sum(len(p.findall(r)) for r in red for _, p, _ in PATTERNS))
    # runs
    zs, sent_z, log_z, tz = run_pipeline(tk, ZERO_SHOT); cz = summarize("zero-shot", zs, tz)
    fs, sent_f, log_f, tf = run_pipeline(tk, FEW_SHOT); cf = summarize("few-shot", fs, tf)
    print("retries logged (zero-shot run):", len(log_z), "| wait range: %.4f-%.4f" % (min(w for *_, w in log_z), max(w for *_, w in log_z)),
          "| retry numbers:", sorted({r for _, r, _ in log_z}))
    print("\nzero-shot confusion (rows true, cols predicted):")
    print(pd.crosstab(cz.true, cz.category).reindex(index=CATS, columns=CATS, fill_value=0).to_string())
    print("zero-shot prompt est tokens:", est_tokens(ZERO_SHOT), "| few-shot prompt est tokens:", est_tokens(FEW_SHOT))
    # privacy assertion
    for msgs in sent_z + sent_f:
        u = msgs[1]["content"]
        assert not any(p.search(u) for _, p, _ in PATTERNS), "PII leaked to prompt"
    for msgs, t in zip(sent_z, [x for x in tk.itertuples() if x.text.strip() and est_tokens(x.text) <= MAX_INPUT_TOKENS]):
        assert msgs[1]["content"] == redact(t.text)
    print("PRIVACY ASSERTION PASSED: no email/phone/sale id in", len(sent_z) + len(sent_f), "prompts; user content == redacted text")
    # budget demo
    bd, _, _, tb = run_pipeline(tk, ZERO_SHOT, budget=6000)
    bd["segment_name"] = ""; bd["priority"] = ""; bd["route"] = ""
    print("\nbudget demo (TOKEN_BUDGET=6000):", bd.status.value_counts().to_dict(), "tokens", tb)
    bd.drop(columns="true").rename(columns={}).to_csv("outputs/triage_budget_demo.csv", index=False)
    # final routing
    fin, _, _, tfin = run_pipeline(tk, FEW_SHOT, budget=100000)
    fin = fin.merge(seg[["customer_id", "segment_name", "is_premium"]], on="customer_id", how="left")
    fin["is_premium"] = fin.is_premium.fillna(False).astype(bool)
    human = fin.status.isin(["skipped_empty", "flagged_long", "flagged_invalid_output", "budget_exhausted"])
    fin["route"] = "support_queue"; fin["priority"] = "NORMAL"
    prem = ~human & (fin.category != "fraud") & fin.is_premium
    fin.loc[prem, ["route", "priority"]] = ["premium_desk", "HIGH"]
    fin.loc[~human & (fin.category == "fraud"), ["route", "priority"]] = ["security_team", "HIGH"]
    fin.loc[human, ["route", "priority"]] = ["human_review", "NORMAL"]
    fin = fin[["ticket_id", "customer_id", "status", "category", "segment_name", "priority", "route", "tokens_used"]]
    fin.to_csv("outputs/triage_results.csv", index=False)
    print("\nfinal: rows", len(fin), "| statuses", fin.status.value_counts().to_dict())
    print("routes:", fin.route.value_counts().to_dict(), "| priority:", fin.priority.value_counts().to_dict())
    print("customers without segment row:", int(fin.segment_name.isna().sum()))
