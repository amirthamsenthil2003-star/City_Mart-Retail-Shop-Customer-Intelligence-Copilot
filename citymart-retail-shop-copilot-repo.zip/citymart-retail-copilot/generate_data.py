"""generate_data.py -- deterministic synthetic data for the CityMart Retail Shop Customer Intelligence capstone.
Run:  python generate_data.py        (writes ./data/raw/*.csv and ./data/policies/*.txt)
Uses only the Python standard library. All data is synthetic and fictional."""
import csv, math, os, random
from datetime import datetime, timedelta

rng = random.Random(42)
RAW, POL = os.path.join("data", "raw"), os.path.join("data", "policies")
os.makedirs(RAW, exist_ok=True); os.makedirs(POL, exist_ok=True)

CITIES = ["Chennai", "Mumbai", "Bengaluru", "Delhi", "Hyderabad", "Pune"]
PRODUCTS = [  # (name, category, price_inr)  -- items sold in a CityMart retail shop
    ("Basmati Rice 1kg", "Grocery", 129), ("Toor Dal 1kg", "Grocery", 165), ("Atta 5kg", "Grocery", 245),
    ("Sunflower Oil 1L", "Grocery", 155), ("Sugar 1kg", "Grocery", 48), ("Salt 1kg", "Grocery", 24),
    ("Tea Powder 250g", "Grocery", 120), ("Biscuits 150g", "Grocery", 30),
    ("Detergent Powder 1kg", "Household", 110), ("Dishwash Liquid 500ml", "Household", 99),
    ("Floor Cleaner 1L", "Household", 175), ("Steel Water Bottle 750ml", "Household", 320),
    ("Storage Box Set", "Household", 450), ("Bath Towel", "Household", 299),
    ("Double Bed Sheet", "Household", 799), ("LED Bulb 9W", "Household", 85),
    ("Notebook Pack of 5", "Stationery", 250), ("Ball Pens Pack of 10", "Stationery", 60),
    ("Geometry Box", "Stationery", 140), ("Highlighter Set", "Stationery", 180),
    ("Sticky Notes", "Stationery", 75), ("Stapler", "Stationery", 95),
    ("Colour Pencils 24", "Stationery", 199), ("School Bag", "Stationery", 650),
    ("Cotton T-Shirt", "Apparel", 399), ("Denim Jeans", "Apparel", 1199),
    ("Formal Shirt", "Apparel", 899), ("Cotton Kurta", "Apparel", 799),
    ("Sports Socks 3 Pack", "Apparel", 199), ("Track Pants", "Apparel", 599),
    ("Winter Jacket", "Apparel", 1799), ("Running Shoes", "Apparel", 1499),
    ("Wireless Earbuds", "Electronics", 1499), ("Power Bank 10000mAh", "Electronics", 1299),
    ("USB-C Cable 1m", "Electronics", 299), ("Phone Charger 20W", "Electronics", 799),
    ("Smart Bulb", "Electronics", 599), ("Bluetooth Speaker", "Electronics", 1999),
    ("Phone Stand", "Electronics", 349), ("Memory Card 64GB", "Electronics", 549)]
CAT_IDX = {}
for i, (_, c, _) in enumerate(PRODUCTS):
    CAT_IDX.setdefault(c, []).append(i)

def write(name, header, rows):
    with open(os.path.join(RAW, name), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)

def poisson(lam):
    L, k, p = math.exp(-lam), 0, 1.0
    while True:
        p *= rng.random()
        if p <= L:
            return k
        k += 1

def mangle_city(c):
    r = rng.random()
    return c.lower() if r < .20 else c.upper() if r < .32 else (" " + c + " ") if r < .42 else c

def mangle_gender(g):
    opts = {"male": ["male", "Male", "M", "m", "MALE"], "female": ["female", "Female", "F", "f", "FEMALE"]}[g]
    return rng.choice(opts)

# ---------------- products ----------------
write("products.csv", ["product_id", "product_name", "category", "price_inr"],
      [[f"P{i+1:03d}", n, c, p] for i, (n, c, p) in enumerate(PRODUCTS)])

# ---------------- customers ----------------
N_CUST = 1200
IMPOSSIBLE_AGE = {10: 280, 110: -4, 210: 0, 310: 150, 410: 999, 510: 200}
cust, arche = [], {}
for i in range(N_CUST):
    cid = f"C{i+1:04d}"
    r = rng.random()
    arche[cid] = "premium" if r < .20 else "frequent" if r < .60 else "rare"
    signup = datetime(2024, 1, 1) + timedelta(days=rng.randint(0, 455))
    age = IMPOSSIBLE_AGE.get(i, rng.randint(18, 60))
    age = "" if (i not in IMPOSSIBLE_AGE and rng.random() < .05) else age
    gender = "" if rng.random() < .03 else mangle_gender(rng.choice(["male", "female"]))
    cust.append([cid, mangle_city(rng.choice(CITIES)), signup.strftime("%Y-%m-%d"), age, gender])
write("customers.csv", ["customer_id", "city", "signup_date", "age", "gender"], cust)

# ---------------- sales ----------------
WIN_START, WIN_DAYS = datetime(2025, 4, 1), 183          # 2025-04-01 .. 2025-09-30
RATE = {"premium": 1.0, "frequent": 3.5, "rare": 0.5}   # expected sales per month
def pick_product(a):
    if a == "premium":      # big-ticket shoppers: electronics and apparel
        pool = CAT_IDX["Electronics"] if rng.random() < .6 else CAT_IDX["Apparel"]
        return rng.choice(pool), rng.randint(1, 2)
    if a == "frequent":     # everyday basket: grocery, household, stationery
        return rng.choice(CAT_IDX["Grocery"] + CAT_IDX["Household"] + CAT_IDX["Stationery"]), rng.randint(1, 3)
    return rng.choice(CAT_IDX["Grocery"] + CAT_IDX["Household"] + CAT_IDX["Stationery"] + CAT_IDX["Apparel"]), rng.randint(1, 2)

rows, oid = [], 100000
for cid, a in arche.items():
    for _ in range(poisson(RATE[a] * 6.0)):
        oid += 1
        pi, qty = pick_product(a)
        ts = WIN_START + timedelta(days=rng.randint(0, WIN_DAYS - 1), hours=rng.randint(7, 22),
                                   minutes=rng.randint(0, 59), seconds=rng.randint(0, 59))
        disc = rng.choice([0, 0, 0, 5, 10, 15, 20, 25, 40])
        status = "cancelled" if rng.random() < .10 else "completed"
        amount = round(PRODUCTS[pi][2] * qty * (1 - disc / 100), 2)
        if status == "cancelled":
            wait = ""
        else:
            wait = rng.randint(46, 75) if rng.random() < .10 else max(8, min(45, int(round(rng.gauss(24, 8)))))  # minutes waited at the pickup counter
            if rng.random() < .06:
                wait = ""
        rows.append({"sale_id": f"SALE-{oid}", "customer_id": cid, "product_id": f"P{pi+1:03d}", "quantity": qty,
                     "sale_ts": ts, "status": status, "discount_pct": disc, "sale_amount": amount,
                     "counter_wait_minutes": wait})
out = []
for k, r in enumerate(rows):
    if k % 100 == 7 and r["status"] == "completed" and r["counter_wait_minutes"] != "":
        r["counter_wait_minutes"] = -10                          # impossible negative duration (planted)
    if r["status"] == "completed" and rng.random() < .01:
        r["sale_amount"] = "N/A" if rng.random() < .5 else "error"   # unparseable amount (planted)
    base = [r["sale_id"], r["customer_id"], r["product_id"], r["quantity"], r["sale_ts"].strftime("%Y-%m-%d %H:%M:%S"),
            r["status"], r["discount_pct"], r["sale_amount"], r["counter_wait_minutes"]]
    out.append(base)
    if rng.random() < .05:   # earlier 'pending' record of the same sale (partial duplicate)
        early = list(base); early[4] = (r["sale_ts"] - timedelta(minutes=rng.randint(1, 10))).strftime("%Y-%m-%d %H:%M:%S")
        early[5] = "pending"; early[8] = ""
        out.append(early)
    if rng.random() < .01:   # exact duplicate
        out.append(list(base))
rng.shuffle(out)
write("sales.csv", ["sale_id", "customer_id", "product_id", "quantity", "sale_ts", "status",
                     "discount_pct", "sale_amount", "counter_wait_minutes"], out)

# ---------------- support tickets ----------------
T = {"billing": ["I was charged twice for purchase {o}. Please refund the extra payment. My email is {e}.",
                 "The invoice for {o} shows a wrong amount. Call me on {p} to correct the bill.",
                 "Extra money was deducted for purchase {o}, please check the bill. Contact {e}."],
     "store_service": ["I have been waiting at the pickup counter for {o} and no staff member has come. Please call {p}.",
                       "My pre-booked items for {o} were not ready, they promised them in 20 minutes. Write to {e}.",
                       "The staff marked {o} as handed over but I never received the items. Call {p}."],
     "technical": ["The shop app crashes every time I open the cart. I tried to place {o} again and got an error. Email {e}.",
                   "I cannot login to my loyalty account, the OTP never arrives on {p}.",
                   "The payment page shows an error and the app freezes when I apply a coupon. Purchase {o}."],
     "fraud": ["There is an unauthorized transaction on my card linked to purchase {o}. I did not make it. Call {p}.",
               "Someone hacked my loyalty account and used my reward points. This is fraud, contact {e}.",
               "I was charged for purchase {o} that I never made, it looks like fraud on my account. Call {p}."]}
sale_by_cust = {}
for r in out:
    sale_by_cust.setdefault(r[1], r[0])
cust_with_sales = sorted(sale_by_cust)
tickets = []
cats = list(T)
for n in range(1, 157):
    cat = cats[(n - 1) % 4]
    cid = rng.choice(cust_with_sales)
    txt = rng.choice(T[cat]).format(o=sale_by_cust[cid], e=f"user{n}@example.com", p=str(rng.choice("6789")) + "".join(rng.choice("0123456789") for _ in range(9)))
    tickets.append([f"T{n:04d}", cid, sale_by_cust[cid], txt, cat])
FILL = "The same problem keeps happening and nobody has given me a clear answer yet. "
for n in range(157, 161):                         # 4 empty tickets
    tickets.append([f"T{n:04d}", rng.choice(cust_with_sales), "", "", "none"])
for n in range(161, 165):                         # 4 very long tickets (~520 words)
    tickets.append([f"T{n:04d}", rng.choice(cust_with_sales), "", ("My pickup at the counter was very late. " + FILL * 40).strip(), "store_service"])
rng.shuffle(tickets)
write("tickets.csv", ["ticket_id", "customer_id", "sale_id", "text", "true_category"], tickets)

# ---------------- policy documents ----------------
DOCS = {
"refund_policy.txt": """Refund Policy. A refund can be requested only for sales whose status is completed. Sales with status cancelled were never charged, so no refund applies to them. If a completed pre-booked sale keeps the customer waiting more than 45 minutes at the pickup counter, the customer receives a full refund of the sale amount. If the counter wait is 45 minutes or less, no waiting-time refund is paid. Refunds up to INR 1000 are approved automatically by the billing system. A refund above INR 1000 must be approved by a human store manager before money is returned. Approved refunds are credited to the original payment method within 5 working days. A refund request must be raised within 7 days of the purchase date.""",
"pickup_policy.txt": """Store and Pickup Policy. Every CityMart shop is open from 9 AM to 10 PM and pre-booked items are promised ready at the pickup counter within 30 minutes of order confirmation. The shops are located in Chennai, Mumbai, Bengaluru, Delhi, Hyderabad and Pune. A packing fee of INR 25 is charged on pre-booked orders below INR 199, and packing is free on orders of INR 199 or more. During festival rush the promised time may extend to 60 minutes and the shop displays a rush notice. Counter staff will attempt to contact the customer twice before marking a pre-booked order as uncollected. Electronics items are handed over only after the customer shares a one time password with the counter staff.""",
"payment_policy.txt": """Payment Policy. Customers can pay using UPI, debit card, credit card or cash at the counter. Cash payment for pre-booked orders is accepted only for orders up to INR 2500. If a payment fails but money is deducted, the amount is returned automatically within 48 hours. A customer who sees two charges for one purchase should raise a billing ticket with the sale identifier. Loyalty reward points can be used for any purchase and are never refunded as cash. Coupons cannot be combined with reward points on the same sale.""",
"privacy_policy.txt": """Privacy Policy. Customer phone numbers and email addresses are used only for purchase updates and support. Support tickets are processed with personal details masked before any automated tool reads them. Purchase history linked to a loyalty account is deleted from active systems 180 days after the last purchase. A customer can ask for account deletion and the request is completed within 30 days. Payment card numbers are never stored by the support system.""",
"escalation_policy.txt": """Escalation Policy. A ticket about fraud or an unauthorized transaction is marked high priority and sent to the security team within 2 hours. Tickets from premium customers are answered within 1 hour, and all other tickets within 24 hours. If an automated assistant cannot resolve a ticket within 6 steps, it must hand the case to a human agent with a short summary. A human agent must call the customer back if such a high-value request is rejected."""}
for fn, body in DOCS.items():
    with open(os.path.join(POL, fn), "w", encoding="utf-8") as f:
        f.write(body + "\n")

# ---------------- policy evaluation questions ----------------
QA = [("What counter wait makes a completed sale eligible for a full refund?", "refund_policy.txt", "more than 45 minutes"),
      ("Who must approve a refund above INR 1000?", "refund_policy.txt", "human store manager"),
      ("How many days do I have to raise a refund request?", "refund_policy.txt", "within 7 days"),
      ("What is the packing fee on small pre-booked orders?", "pickup_policy.txt", "INR 25"),
      ("On orders of what value is packing free?", "pickup_policy.txt", "INR 199 or more"),
      ("Why does the electronics handover need a one time password?", "pickup_policy.txt", "one time password"),
      ("Is cash payment accepted for a large pre-booked order?", "payment_policy.txt", "INR 2500"),
      ("How soon is money returned when a payment fails but is deducted?", "payment_policy.txt", "48 hours"),
      ("Can loyalty reward points be refunded as cash?", "payment_policy.txt", "never refunded as cash"),
      ("When is purchase history deleted from active systems?", "privacy_policy.txt", "180 days"),
      ("How fast must a fraud ticket reach the security team?", "escalation_policy.txt", "within 2 hours"),
      ("After how many steps must an automated assistant hand over to a human?", "escalation_policy.txt", "6 steps"),
      ("What is the favourite colour of the company mascot?", "NONE", ""),
      ("Who won the cricket world cup final?", "NONE", "")]
with open(os.path.join(RAW, "policy_eval.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["question", "expected_doc", "expected_fact"]); w.writerows(QA)

# ---------------- agent scenarios (simulated refund requests) ----------------
from collections import Counter
cnt = Counter(r[0] for r in out)
def clean_row(r):                                    # single-record, fully valid sale
    try:
        return cnt[r[0]] == 1 and r[5] in ("completed", "cancelled") and float(r[7]) > 0 and \
            (r[5] == "cancelled" or (r[8] != "" and 8 <= int(r[8]) <= 75))
    except ValueError:
        return False
ok_rows = sorted((r for r in out if clean_row(r)), key=lambda r: r[0])
def first(pred):
    return next(r for r in ok_rows if pred(r))
late_small = [r for r in ok_rows if r[5] == "completed" and int(r[8]) > 45 and float(r[7]) <= 1000][:2]
late_big = first(lambda r: r[5] == "completed" and int(r[8]) > 45 and float(r[7]) > 1000)
on_time = first(lambda r: r[5] == "completed" and int(r[8]) <= 45)
cancelled = first(lambda r: r[5] == "cancelled")
SC = []
for r in late_small:
    SC.append((r[1], f"My purchase {r[0]} kept me waiting far too long at the pickup counter. I would like a refund.", "REFUND", float(r[7])))
SC.append((late_big[1], f"Purchase {late_big[0]} was ready far too late at the counter, please refund me.", "ESCALATE", float(late_big[7])))
SC.append((on_time[1], f"Please refund purchase {on_time[0]}, I did not like the counter service.", "DENIED", 0))
SC.append((cancelled[1], f"I want my money back for purchase {cancelled[0]}.", "DENIED", 0))
SC.append(("C0001", "Refund for purchase SALE-999999 please.", "NOT_FOUND", 0))
SC.append((late_small[0][1], f"[LOOP] Refund purchase {late_small[0][0]}.", "FALLBACK", 0))
with open(os.path.join(RAW, "agent_scenarios.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["scenario_id", "customer_id", "message", "expected_outcome", "expected_refund_inr"])
    for i, (cid, msg, oc, amt) in enumerate(SC, 1):
        w.writerow([f"S{i}", cid, msg, oc, f"{amt:.2f}"])
print("generated: customers=%d products=%d sales_raw=%d tickets=%d" % (len(cust), len(PRODUCTS), len(out), len(tickets)))
